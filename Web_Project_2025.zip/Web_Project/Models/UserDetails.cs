﻿using Microsoft.AspNetCore.Identity;
namespace Web_Project.Models
{
    public class UserDetails : IdentityUser
    {
    }
}
